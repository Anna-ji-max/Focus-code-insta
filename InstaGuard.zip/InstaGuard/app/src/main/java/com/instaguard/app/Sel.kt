package com.instaguard.app

/**
 * Instagram view-IDs used to recognise screens.
 * Instagram renames IDs between versions. If a screen is not detected after an
 * Instagram update, turn on "Debug bubble" in the app, tap the bubble on that screen,
 * and paste the copied IDs here (add them to the matching list).
 */
object Sel {
    const val IG = "com.instagram.android"

    // Bottom tab buttons
    val homeTab = listOf("feed_tab")
    val searchTab = listOf("search_tab")
    val reelsTab = listOf("clips_tab")
    val profileTab = listOf("profile_tab")

    // Fallback by label (English) - only matched in the bottom strip of the screen
    val homeDesc = listOf("Home")
    val searchDesc = listOf("Search and explore", "Search")
    val reelsDesc = listOf("Reels")
    val profileDesc = listOf("Profile")

    // Full screen story viewer  -> allowed
    val story = listOf(
        "reel_viewer_texture_view", "reel_viewer_media_layout",
        "reel_viewer_progress_bar", "reel_viewer_root", "story_viewer_container"
    )

    // Reels pager (the swipe-up-for-next-reel screen)
    val clips = listOf("clips_viewer_view_pager", "clips_viewer_container", "clips_viewer_root")

    // Camera / create screens -> allowed
    val camera = listOf("camera_shutter_button", "quick_capture_root_container", "camera_preview", "capture_button")

    // Chats -> allowed
    val dm = listOf(
        "row_thread_composer_edittext", "thread_composer_container", "direct_thread_header",
        "inbox_refreshable_thread_list_recyclerview", "direct_inbox_container", "direct_text_message_text_view"
    )

    // A feed post row (used to detect a post opened from chat)
    val post = listOf(
        "row_feed_photo_profile_name", "row_feed_button_like",
        "row_feed_view_group_buttons", "row_feed_comment_textview_layout"
    )

    // Stories tray at top of Home (stays visible)
    val tray = listOf("reels_tray_container", "reel_tray_container", "stories_tray")

    // Profile screen parts
    val profileHeader = listOf("profile_header_container", "profile_header_actions_top_row", "row_profile_header_imageview")
    val highlights = listOf("profile_header_highlights_tray", "highlights_tray", "profile_highlights_container")
    val profileTabs = listOf("profile_tabs_container", "profile_tab_layout")

    // Comment sheet / comment composer (so comments can be scrolled and typed)
    val comments = listOf(
        "layout_comment_thread_edittext", "layout_comment_thread_post_button_click_area",
        "row_comment_textview_comment", "comment_composer_parent"
    )

    val actionBar = listOf("action_bar_container", "action_bar")
}
