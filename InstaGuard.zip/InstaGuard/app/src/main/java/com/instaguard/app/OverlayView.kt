package com.instaguard.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs

/**
 * Instagram-style "still loading" skeleton that never finishes.
 * Swallows every touch. The top [clearH] pixels are transparent (Instagram shows through)
 * but still absorb touches: taps there are re-sent to Instagram, vertical drags are dropped,
 * and horizontal swipes are re-sent as purely horizontal swipes.
 */
class OverlayView(ctx: Context) : View(ctx) {

    enum class Look { FEED, GRID, DIM, CLEAR }

    var look: Look = Look.CLEAR
        set(v) {
            if (field != v) { field = v; syncAnim(); invalidate() }
        }

    /** Height (px) of the transparent strip at the top. */
    var clearH: Int = 0
        set(v) { if (field != v) { field = v; invalidate() } }

    var onTap: ((Float, Float) -> Unit)? = null
    var onHSwipe: ((Float, Float, Float, Long) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private var bg = 0xFF0C1014.toInt()
    private var base = 0xFF1A2026.toInt()
    private var hi = 0xFF2A323A.toInt()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()
    private var shimmer: LinearGradient? = null
    private var sweep: SweepGradient? = null
    private var band = 1f
    private var t = 0f

    private var downX = 0f
    private var downY = 0f
    private var downT = 0L
    private var inPass = false

    private val anim: ValueAnimator by lazy {
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1300
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
        }
    }

    init {
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        ringPaint.style = Paint.Style.STROKE
        ringPaint.strokeWidth = 3f * d
        ringPaint.strokeCap = Paint.Cap.ROUND
    }

    fun setColors(newBg: Int, newBase: Int, newHi: Int) {
        if (newBg == bg && newBase == base && newHi == hi) return
        bg = newBg; base = newBase; hi = newHi
        shimmer = null
        invalidate()
    }

    private fun syncAnim() {
        val run = (look == Look.FEED || look == Look.GRID) && isAttachedToWindow && visibility == VISIBLE
        if (run && !anim.isStarted) anim.start()
        else if (!run && anim.isStarted) anim.cancel()
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); syncAnim() }
    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); syncAnim() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility); syncAnim()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        shimmer = null; sweep = null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; downT = e.eventTime
                inPass = e.y < clearH
            }
            MotionEvent.ACTION_UP -> {
                if (inPass) {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    val dt = e.eventTime - downT
                    if (abs(dx) < 10f * d && abs(dy) < 10f * d) {
                        if (dt < 700) onTap?.invoke(downX, downY)
                    } else if (abs(dx) > 2f * abs(dy) && abs(dx) > 24f * d) {
                        onHSwipe?.invoke(downX, downY, e.rawX, dt)
                    }
                }
                inPass = false
            }
            MotionEvent.ACTION_CANCEL -> inPass = false
        }
        return true
    }

    override fun onDraw(c: Canvas) {
        when (look) {
            Look.CLEAR -> return
            Look.DIM -> { c.drawColor((bg and 0x00FFFFFF) or (0xF2 shl 24)); return }
            else -> {}
        }
        val w = width.toFloat()
        val top = clearH.toFloat()
        val h = height.toFloat() - top
        if (h <= 0f) return
        c.save()
        c.clipRect(0f, top, w, top + h)
        c.drawColor(bg)
        c.translate(0f, top)

        if (shimmer == null) {
            band = w * 0.8f
            shimmer = LinearGradient(0f, 0f, band, 0f, intArrayOf(base, hi, base),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        }
        m.setTranslate(-band + (w + band) * t, 0f)
        shimmer!!.setLocalMatrix(m)
        paint.shader = shimmer
        if (look == Look.FEED) drawFeed(c, w, h) else drawGrid(c, w, h)
        c.restore()
    }

    private fun bar(c: Canvas, l: Float, t: Float, r: Float, b: Float) =
        c.drawRoundRect(l, t, r, b, 4f * d, 4f * d, paint)

    private fun drawFeed(c: Canvas, w: Float, h: Float) {
        val cx = w / 2f
        val cy = 20f * d
        if (sweep == null) {
            sweep = SweepGradient(cx, cy, intArrayOf(
                0xFFFEDA75.toInt(), 0xFFFA7E1E.toInt(), 0xFFD62976.toInt(),
                0xFF962FBF.toInt(), 0xFF4F5BD5.toInt(), 0xFFFEDA75.toInt()), null)
        }
        ringPaint.shader = sweep
        c.save()
        c.rotate(t * 360f, cx, cy)
        c.drawArc(cx - 10f * d, cy - 10f * d, cx + 10f * d, cy + 10f * d, 0f, 270f, false, ringPaint)
        c.restore()

        var y = 44f * d
        while (y < h) {
            c.drawCircle(28f * d, y + 20f * d, 16f * d, paint)
            bar(c, 56f * d, y + 12f * d, 186f * d, y + 22f * d)
            bar(c, 56f * d, y + 28f * d, 136f * d, y + 36f * d)
            y += 52f * d
            c.drawRect(0f, y, w, y + w, paint)
            y += w + 12f * d
            for (i in 0..2) c.drawCircle(24f * d + i * 36f * d, y + 12f * d, 11f * d, paint)
            c.drawCircle(w - 24f * d, y + 12f * d, 11f * d, paint)
            y += 36f * d
            bar(c, 12f * d, y, w * 0.45f, y + 10f * d)
            bar(c, 12f * d, y + 18f * d, w * 0.75f, y + 28f * d)
            y += 56f * d
        }
    }

    private fun drawGrid(c: Canvas, w: Float, h: Float) {
        val gap = 2f * d
        val tile = (w - 2f * gap) / 3f
        var y = 0f
        while (y < h) {
            for (i in 0..2) {
                val x = i * (tile + gap)
                c.drawRect(x, y, x + tile, y + tile, paint)
            }
            y += tile + gap
        }
    }
}
