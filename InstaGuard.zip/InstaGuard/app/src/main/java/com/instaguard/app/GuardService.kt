package com.instaguard.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.atomic.AtomicBoolean

/**
 * IDLE  : Instagram closed. Only listens to "Instagram window opened". No overlays, no thread, no work.
 * ACTIVE: Instagram open. Overlay windows + worker thread exist.
 * Instagram closes / screen off / app paused -> back to IDLE and everything is released.
 *
 * With the "Display over other apps" permission the cover is a normal app overlay, which Android
 * draws BELOW system UI (shade, volume, screenshot, nav buttons). Without it, the cover falls back to
 * an accessibility overlay (above everything) and hides itself while system UI is in front.
 */
class GuardService : AccessibilityService() {

    enum class Mode { ALLOW, HOME, SEARCH, REELS_TAB, REEL_VIEW, POST_VIEW, PROFILE_OTHER, PAUSED, AWAY }

    class Plan(
        val mode: Mode,
        val cover: Rect? = null,
        val look: OverlayView.Look = OverlayView.Look.CLEAR,
        val tabBlock: Rect? = null,
        val passH: Int = 0            // transparent strip at top of cover (taps + horizontal swipes pass through)
    )

    private lateinit var wm: WindowManager
    private var cover: OverlayView? = null
    private var tabBlock: OverlayView? = null
    private var bubble: TextView? = null
    private lateinit var coverLp: WindowManager.LayoutParams
    private lateinit var tabLp: WindowManager.LayoutParams

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    @Volatile private var worker: Handler? = null
    private val pending = AtomicBoolean(false)

    private var active = false                 // main thread only
    private var lastPlan: Plan? = null
    private var lastReal: Plan? = null
    private var muted = false
    private lateinit var audio: AudioManager
    @Volatile private var navTopCache = 0
    @Volatile private var trayBottomCache = 0
    @Volatile private var lastRedirect = 0L
    private var awaySince = 0L                 // worker thread only

    private var d = 1f
    private var screenW = 0
    private var screenH = 0
    private var statusH = 0

    private fun dp(v: Int) = (v * d).toInt()

    // ---------------------------------------------------------------- lifecycle

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> stop()
                Intent.ACTION_USER_PRESENT -> checkForeground()
            }
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        main.post {
            if (!Prefs.enabled(this)) stop()
            else if (!active) checkForeground()
            else { lastPlan?.let { render(it) }; schedule(true) }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        d = resources.displayMetrics.density
        if (Prefs.mutedByUs(this)) {            // we were killed while muting: give the sound back
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            Prefs.setMutedByUs(this, false)
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(screenReceiver, f)
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        setInfo(false)
        checkForeground()
    }

    override fun onInterrupt() { setMuted(false) }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        stop()
        try { unregisterReceiver(screenReceiver) } catch (e: Exception) {}
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Exception) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (active) { readMetrics(); schedule(true) }
    }

    /** Idle = only "Instagram window opened". Active = the events needed to react. */
    private fun setInfo(activeMode: Boolean) {
        val i = serviceInfo ?: return
        if (activeMode) {
            i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED or
                AccessibilityEvent.TYPE_VIEW_SCROLLED or
                AccessibilityEvent.TYPE_VIEW_CLICKED
            i.packageNames = null
            i.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
        } else {
            i.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            i.packageNames = arrayOf(Sel.IG)
            i.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
        }
        serviceInfo = i
    }

    private fun checkForeground() {
        if (active || !Prefs.enabled(this)) return
        val p = try { rootInActiveWindow?.packageName?.toString() } catch (e: Exception) { null }
        if (p == Sel.IG) start()
    }

    private fun start() {
        if (active || !Prefs.enabled(this)) return
        active = true
        readMetrics()
        coverLp = newLp()
        tabLp = newLp()
        try {
            val c = OverlayView(this).also { it.visibility = View.INVISIBLE; hook(it) }
            val t = OverlayView(this).also { it.visibility = View.INVISIBLE }
            wm.addView(c, coverLp)
            wm.addView(t, tabLp)
            cover = c; tabBlock = t
        } catch (e: Exception) {
            active = false
            return
        }
        thread = HandlerThread("insta-guard").also { it.start() }
        worker = Handler(thread!!.looper)
        awaySince = 0L
        setInfo(true)
        lastReal?.let { render(it) }
        schedule(true)
        settle()
    }

    private fun stop() {
        setMuted(false)
        if (!active) return
        active = false
        pending.set(false)
        try { cover?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { tabBlock?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (e: Exception) {}
        cover = null; tabBlock = null; bubble = null
        lastPlan = null
        worker?.removeCallbacksAndMessages(null)
        thread?.quitSafely()
        thread = null; worker = null
        setInfo(false)
    }

    // ---------------------------------------------------------------- events

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val type = e.eventType

        if (!active) {
            if (pkg == Sel.IG && type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) start()
            return
        }
        if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            schedule(true)
            if (pkg == Sel.IG) settle()
            return
        }
        if (pkg != Sel.IG) return
        when (type) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> { optimistic(e); schedule(true) }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> { backstop(e); schedule(false) }
            else -> schedule(false)
        }
    }

    /** A tab tap is covered before Instagram finishes drawing the new tab. */
    private fun optimistic(e: AccessibilityEvent) {
        val src = e.source ?: return
        val r = Rect()
        src.getBoundsInScreen(r)
        if (r.top < screenH * 0.9 || r.width() > screenW / 4 || r.height() > dp(100)) return
        val key = ("" + (src.viewIdResourceName ?: "") + " " + (src.contentDescription ?: "")).lowercase()
        val nt = if (navTopCache > 0) navTopCache else r.top
        val keep = lastPlan?.tabBlock
        val p = when {
            key.contains("clips") || key.contains("reels") ->
                Plan(Mode.REELS_TAB, Rect(0, statusH, screenW, nt), OverlayView.Look.FEED, r)
            key.contains("search") ->
                Plan(Mode.SEARCH, Rect(0, statusH, screenW, nt), OverlayView.Look.GRID, keep)
            key.contains("feed_tab") || key.contains("home") ->
                Plan(Mode.HOME, Rect(0, statusH, screenW, nt), OverlayView.Look.FEED, keep, homeTop() - statusH)
            key.contains("profile") || key.contains("direct") || key.contains("message") ->
                Plan(Mode.ALLOW, null, OverlayView.Look.CLEAR, keep)
            else -> null
        }
        if (p != null) render(p)
    }

    /** Extra safety: if Instagram still scrolls vertically on a blocked screen, scroll it back. */
    private fun backstop(e: AccessibilityEvent) {
        val m = lastPlan?.mode ?: return
        if (m == Mode.ALLOW || m == Mode.AWAY || m == Mode.PAUSED) return
        if (Build.VERSION.SDK_INT >= 28) { if (e.scrollDeltaY <= 0) return }
        else if (e.fromIndex <= 0) return
        val src = e.source ?: return
        worker?.post { src.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) }
    }

    /** Coalesces bursts of events into one analysis. Urgent events jump the queue. */
    private fun schedule(urgent: Boolean) {
        val w = worker ?: return
        if (urgent) {
            pending.set(true)
            w.postAtFrontOfQueue(tick)
        } else if (pending.compareAndSet(false, true)) {
            val delay = if (lastPlan?.mode == Mode.ALLOW) 250L else 50L
            w.postDelayed(tick, delay)
        }
    }

    private val tick = Runnable { runTick() }
    private val poll = Runnable { runTick() }

    private fun runTick() {
        val w = worker
        pending.set(false)
        val plan = try { analyzeActive() } catch (e: Exception) { null }
        if (plan != null) main.post {
            if (!active) return@post
            if (plan.mode == Mode.AWAY) stop() else render(plan)
        }
        // While something else is in front (shade, launcher, dialog) re-check twice a second.
        if (plan?.mode == Mode.PAUSED && w != null) {
            w.removeCallbacks(poll)
            w.postDelayed(poll, 500)
        }
    }

    /**
     * Instagram often finishes drawing a screen after the first events, and our event settings
     * only take effect a moment after start(). A few follow-up checks make sure the cover shows
     * even if Instagram then goes quiet.
     */
    private fun settle() {
        val w = worker ?: return
        w.removeCallbacks(tick)
        for (ms in longArrayOf(150L, 400L, 900L, 1800L)) w.postDelayed(tick, ms)
    }

    // ---------------------------------------------------------------- analysis (worker thread)

    private fun analyzeActive(): Plan? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString()
        if (pkg == Sel.IG) {
            awaySince = 0L
            return analyze(root)
        }
        val now = SystemClock.elapsedRealtime()
        if (awaySince == 0L) awaySince = now
        val sys = pkg == "com.android.systemui" || pkg == "android"
        val grace = if (sys) 120_000L else 20_000L
        return if (now - awaySince > grace) Plan(Mode.AWAY) else Plan(Mode.PAUSED)
    }

    private fun bounds(n: AccessibilityNodeInfo): Rect = Rect().also { n.getBoundsInScreen(it) }

    private fun byId(root: AccessibilityNodeInfo, id: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId(Sel.IG + ":id/" + id)?.firstOrNull { it.isVisibleToUser }

    private fun any(root: AccessibilityNodeInfo, ids: List<String>): AccessibilityNodeInfo? {
        for (i in ids) byId(root, i)?.let { return it }
        return null
    }

    private fun has(root: AccessibilityNodeInfo, ids: List<String>) = any(root, ids) != null

    /** Bottom tab button. The text fallback only accepts small, icon-sized nodes at the very bottom. */
    private fun tabNode(root: AccessibilityNodeInfo, ids: List<String>, desc: List<String>): AccessibilityNodeInfo? {
        any(root, ids)?.let { return it }
        for (s in desc) {
            val list = root.findAccessibilityNodeInfosByText(s) ?: continue
            for (n in list) {
                val r = bounds(n)
                if (n.isVisibleToUser && r.top > screenH * 0.9 && r.width() < screenW / 4 && r.height() < dp(100)) return n
            }
        }
        return null
    }

    private fun isSel(n: AccessibilityNodeInfo?) = n != null && (n.isSelected || n.parent?.isSelected == true)

    private fun homeTop() = if (trayBottomCache > 0) trayBottomCache else statusH + dp(160)

    private fun redirectHome(home: AccessibilityNodeInfo?) {
        val now = System.currentTimeMillis()
        if (now - lastRedirect < 700) return
        lastRedirect = now
        var x = home
        while (x != null && !x.isClickable) x = x.parent
        if (x == null || !x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun analyze(root: AccessibilityNodeInfo): Plan {
        val w = screenW
        val homeN = tabNode(root, Sel.homeTab, Sel.homeDesc)
        val searchN = tabNode(root, Sel.searchTab, Sel.searchDesc)
        val reelsN = tabNode(root, Sel.reelsTab, Sel.reelsDesc)
        val profN = tabNode(root, Sel.profileTab, Sel.profileDesc)
        val tabs = listOf(homeN, searchN, reelsN, profN)

        // Bottom bar counts as visible only if at least two tab buttons are found
        val navTop = if (tabs.count { it != null } >= 2)
            tabs.mapNotNull { n -> n?.let { bounds(it).top } }.filter { it > screenH * 0.75 }.minOrNull()
        else null
        if (navTop != null) navTopCache = navTop
        val bottom = navTop ?: screenH
        val reelsRect = if (navTop != null && reelsN != null) bounds(reelsN) else null
        val topBar = statusH + dp(56)

        fun plan(m: Mode, c: Rect? = null, l: OverlayView.Look = OverlayView.Look.CLEAR, pass: Int = 0) =
            Plan(m, c, l, reelsRect, pass)

        // Comments sheet / comment box open (needs normal scrolling + typing)
        val commenting by lazy {
            has(root, Sel.comments) ||
                (root.findAccessibilityNodeInfosByText("Add a comment")?.any { it.isVisibleToUser } == true)
        }

        // 1. Stories - always allowed
        if (has(root, Sel.story)) return plan(Mode.ALLOW)

        // 2. Reels (tab or pager). From the Reels tab -> bounce to Home. Opened from chat -> view only.
        if (has(root, Sel.clips) || isSel(reelsN)) {
            return if (navTop != null) {
                redirectHome(homeN)
                plan(Mode.REELS_TAB, Rect(0, statusH, w, navTop), OverlayView.Look.FEED)
            } else if (commenting) {
                plan(Mode.ALLOW)          // comments sheet open: let the comment list scroll
            } else {
                plan(Mode.REEL_VIEW, Rect(0, statusH, w, screenH), OverlayView.Look.CLEAR, screenH - statusH)
            }
        }

        // 3. Camera and chats - allowed
        if (has(root, Sel.camera) || has(root, Sel.dm)) return plan(Mode.ALLOW)

        // 4. Profiles: own = allowed. Someone else's = no scrolling at all, grid + highlights hidden
        if (has(root, Sel.profileHeader)) {
            if (isSel(profN)) return plan(Mode.ALLOW)
            val coverTop = any(root, Sel.actionBar)?.let { bounds(it).bottom } ?: topBar
            val gridTop = any(root, Sel.highlights)?.let { bounds(it).top }
                ?: any(root, Sel.profileTabs)?.let { bounds(it).top }
                ?: (screenH * 0.45).toInt()
            val pass = (gridTop - coverTop).coerceAtLeast(0)
            return plan(Mode.PROFILE_OTHER, Rect(0, coverTop, w, bottom), OverlayView.Look.GRID, pass)
        }

        // 5. A post opened from chat: visible, but scrolling is absorbed
        if (has(root, Sel.post) && !isSel(homeN) && !isSel(searchN) && !isSel(profN)) {
            if (commenting) return plan(Mode.ALLOW)
            return plan(Mode.POST_VIEW, Rect(0, statusH, w, bottom), OverlayView.Look.CLEAR, bottom - statusH)
        }

        // 6. Search tab - hide everything including the search bar
        if (isSel(searchN)) return plan(Mode.SEARCH, Rect(0, statusH, w, bottom), OverlayView.Look.GRID)

        // 7. Home tab - no scrolling anywhere. Top bar + stories stay visible (taps and
        //    sideways swipes are passed through), the feed below is covered.
        if (isSel(homeN)) {
            val tray = any(root, Sel.tray)
            val trayBottom = if (tray != null) bounds(tray).bottom.also { trayBottomCache = it } else homeTop()
            return plan(Mode.HOME, Rect(0, statusH, w, bottom), OverlayView.Look.FEED,
                (trayBottom - statusH).coerceAtLeast(0))
        }

        return plan(Mode.ALLOW)
    }

    // ---------------------------------------------------------------- overlay windows (main thread)

    private fun overlayType() =
        if (Settings.canDrawOverlays(this)) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY

    private fun newLp() = WindowManager.LayoutParams(
        1, 1, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28)
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun readMetrics() {
        @Suppress("DEPRECATION")
        val disp = wm.defaultDisplay
        val real = DisplayMetrics()
        @Suppress("DEPRECATION")
        disp.getRealMetrics(real)
        screenW = real.widthPixels
        screenH = real.heightPixels
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        statusH = if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun isDark(): Boolean = when (Prefs.theme(this)) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** Colours copied from Instagram: light = white, dark = navy (new) or black (old). */
    private fun paint(v: OverlayView) {
        if (!isDark()) v.setColors(0xFFFFFFFF.toInt(), 0xFFEFEFEF.toInt(), 0xFFFAFAFA.toInt())
        else if (Prefs.darkShade(this) == 1) v.setColors(0xFF000000.toInt(), 0xFF262626.toInt(), 0xFF3C3C3C.toInt())
        else v.setColors(0xFF0C1014.toInt(), 0xFF1A2026.toInt(), 0xFF2A323A.toInt())
    }

    private fun place(v: OverlayView, p: WindowManager.LayoutParams, r: Rect?, look: OverlayView.Look, passH: Int = 0) {
        try {
            if (r == null || r.width() <= 0 || r.height() <= 0) {
                if (v.visibility == View.VISIBLE) {
                    p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    p.width = 1; p.height = 1
                    v.visibility = View.INVISIBLE
                    wm.updateViewLayout(v, p)
                }
                return
            }
            paint(v)
            v.clearH = passH
            v.look = look
            val touchable = (p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0
            if (v.visibility != View.VISIBLE || !touchable || p.x != r.left || p.y != r.top ||
                p.width != r.width() || p.height != r.height()) {
                p.x = r.left; p.y = r.top; p.width = r.width(); p.height = r.height()
                p.flags = p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                v.visibility = View.VISIBLE
                wm.updateViewLayout(v, p)
            }
        } catch (e: Exception) {}
    }

    private fun render(p: Plan) {
        val c = cover ?: return
        val t = tabBlock ?: return
        lastPlan = p
        val hidden = p.mode == Mode.AWAY || p.mode == Mode.PAUSED
        if (!hidden) lastReal = p
        val on = Prefs.enabled(this) && !hidden
        place(c, coverLp, if (on) p.cover else null, p.look, p.passH)
        place(t, tabLp, if (on) p.tabBlock else null, OverlayView.Look.DIM)
        ensureBubble(Prefs.debug(this) && !hidden)
        bubble?.text = p.mode.name
        // Sound is blocked on the Home feed only (not stories, chats or shared reels/posts)
        setMuted(on && p.mode == Mode.HOME && Prefs.muteHome(this))
    }

    /** Mutes the media volume while the covered Home feed is showing. Only undoes what it did itself. */
    private fun setMuted(want: Boolean) {
        try {
            if (want && !muted && !audio.isStreamMute(AudioManager.STREAM_MUSIC)) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                muted = true
                Prefs.setMutedByUs(this, true)
            } else if (!want && muted) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                muted = false
                Prefs.setMutedByUs(this, false)
            }
        } catch (e: Exception) {}
    }

    // ---------------------------------------------------------------- passing taps / swipes to Instagram
    // The cover swallows every touch. A tap or sideways swipe in its "pass" area is carried out
    // directly on Instagram's own buttons and lists through accessibility actions. No touch is
    // injected, so the cover never has to switch itself off (that is what made it flicker).

    private fun hook(v: OverlayView) {
        v.onTap = { x, y -> worker?.post { doTap(x.toInt(), y.toInt()) } }
        v.onHSwipe = { x0, y0, x1, _ -> worker?.post { doSwipe(x0.toInt(), y0.toInt(), x1 - x0) } }
    }

    private class Hit {
        var click: AccessibilityNodeInfo? = null
        var scroller: AccessibilityNodeInfo? = null
    }

    private fun hasAct(n: AccessibilityNodeInfo, a: AccessibilityAction) =
        n.actionList.contains(a)

    private fun horizontalScroller(n: AccessibilityNodeInfo, r: Rect): Boolean {
        if (!n.isScrollable) return false
        if (hasAct(n, AccessibilityAction.ACTION_SCROLL_LEFT) || hasAct(n, AccessibilityAction.ACTION_SCROLL_RIGHT)) return true
        if (hasAct(n, AccessibilityAction.ACTION_SCROLL_UP) || hasAct(n, AccessibilityAction.ACTION_SCROLL_DOWN)) return false
        return r.width() >= screenW * 0.9 && r.height() <= r.width() * 1.05
    }

    /** Finds the innermost clickable node and the innermost sideways scroller under a screen point. */
    private fun hitTest(root: AccessibilityNodeInfo, x: Int, y: Int): Hit {
        val hit = Hit()
        var budget = 500
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (budget-- <= 0 || depth > 30) return
            val r = Rect()
            n.getBoundsInScreen(r)
            val empty = r.width() <= 0 || r.height() <= 0
            if (!empty && !r.contains(x, y)) return
            if (!empty) {
                if (n.isClickable && n.isEnabled) hit.click = n
                if (horizontalScroller(n, r)) hit.scroller = n
            }
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
            }
        }
        walk(root, 0)
        return hit
    }

    private fun igRoot(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        return if (root.packageName?.toString() == Sel.IG) root else null
    }

    private fun doTap(x: Int, y: Int) {
        val root = igRoot() ?: return
        hitTest(root, x, y).click?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        schedule(true)
    }

    private fun doSwipe(x: Int, y: Int, dx: Float) {
        val root = igRoot() ?: return
        val n = hitTest(root, x, y).scroller ?: return
        val next = dx < 0f                      // finger moves left = show the next item
        val act = if (next) AccessibilityAction.ACTION_SCROLL_RIGHT
                  else AccessibilityAction.ACTION_SCROLL_LEFT
        val ok = hasAct(n, act) && n.performAction(act.id)
        if (!ok) n.performAction(
            if (next) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        schedule(true)
    }

    // ---------------------------------------------------------------- debug helper

    private fun ensureBubble(show: Boolean) {
        if (show && bubble == null) {
            val tv = TextView(this).apply {
                textSize = 8f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xCCD62976.toInt()) }
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                setOnClickListener { dumpIds() }
            }
            val lp = WindowManager.LayoutParams(
                dp(56), dp(56), overlayType(),
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = screenW - dp(64); y = screenH / 3 }
            try { wm.addView(tv, lp); bubble = tv } catch (e: Exception) {}
        } else if (!show && bubble != null) {
            try { wm.removeView(bubble) } catch (e: Exception) {}
            bubble = null
        }
    }

    /** Copies the Instagram view-IDs currently on screen to the clipboard (skim before sharing). */
    private fun dumpIds() {
        worker?.post {
            val sb = StringBuilder("mode=" + lastPlan?.mode + "\n")
            var n = 0
            fun walk(x: AccessibilityNodeInfo?, depth: Int) {
                if (x == null || n > 700) return
                n++
                val id = x.viewIdResourceName?.removePrefix(Sel.IG + ":id/")
                if (id != null) {
                    sb.append(" ".repeat(minOf(depth, 12))).append(id)
                    if (x.isSelected) sb.append(" [selected]")
                    val r = Rect(); x.getBoundsInScreen(r)
                    sb.append(" [" + r.left + "," + r.top + "," + r.right + "," + r.bottom + "]")
                    val cd = x.contentDescription?.toString()
                    if (!cd.isNullOrEmpty() && cd.length <= 25) sb.append(" cd=").append(cd)
                    sb.append('\n')
                }
                for (i in 0 until x.childCount) walk(x.getChild(i), depth + 1)
            }
            walk(rootInActiveWindow, 0)
            main.post {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("instagram ids", sb.toString()))
                Toast.makeText(this, "IDs copied (" + n + " nodes)", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
