package com.instaguard.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences("instaguard", Context.MODE_PRIVATE)

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    /** 0 = follow phone, 1 = light, 2 = dark */
    fun theme(c: Context) = sp(c).getInt("theme", 0)
    fun setTheme(c: Context, v: Int) = sp(c).edit().putInt("theme", v).apply()

    fun debug(c: Context) = sp(c).getBoolean("debug", false)
    fun setDebug(c: Context, v: Boolean) = sp(c).edit().putBoolean("debug", v).apply()

    /** 0 = navy (current Instagram dark), 1 = pure black (older Instagram) */
    fun darkShade(c: Context) = sp(c).getInt("darkShade", 0)
    fun setDarkShade(c: Context, v: Int) = sp(c).edit().putInt("darkShade", v).apply()

    /** Mute media sound while the covered Home feed is showing */
    fun muteHome(c: Context) = sp(c).getBoolean("muteHome", true)
    fun setMuteHome(c: Context, v: Boolean) = sp(c).edit().putBoolean("muteHome", v).apply()

    /** True while InstaGuard itself is holding the media volume muted (crash safety) */
    fun mutedByUs(c: Context) = sp(c).getBoolean("mutedByUs", false)
    fun setMutedByUs(c: Context, v: Boolean) = sp(c).edit().putBoolean("mutedByUs", v).apply()
}
